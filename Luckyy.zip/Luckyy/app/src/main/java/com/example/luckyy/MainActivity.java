package com.example.luckyy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    Button bt1,bt2,bt3;
    public TextView[] tv = new TextView[6];
    public int[] a = {R.id.tv1, R.id.tv2, R.id.tv3, R.id.tv4, R.id.tv5, R.id.tv6};
    public TextView[] tv2 = new TextView[6];
    public int[] b = {R.id.tva, R.id.tvb, R.id.tvc, R.id.tvd, R.id.tve, R.id.tvf};
    public TextView[] tv3 = new TextView[7];
    public int[] c = {R.id.tva1, R.id.tvb2, R.id.tvc3, R.id.tvd4, R.id.tve5, R.id.tvf6, R.id.tvg7};
    public TextView[] tv4 = new TextView[7];
    public int[] d = {R.id.tva11, R.id.tvb22, R.id.tvc33, R.id.tvd44, R.id.tve55, R.id.tvf66, R.id.tvg77};
    int t=0;
    Intent intent;
    Bundle bundle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bt1 = findViewById(R.id.bt1);
        bt2 = findViewById(R.id.bt2);
        bt3 = findViewById(R.id.bt3);
        intent= new Intent(MainActivity.this,stock.class);
        initView();
        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                thread th = new thread();
                th.run();
                for (int p = 0; p < tv.length; p++) {
                    tv[p].setText(" " + th.lottery[p]);
                }
                for (int p = 0; p < tv2.length; p++) {
                    tv2[p].setText(" " + th.lottery2[p]);
                }
                for (int p = 0; p < tv3.length; p++) {
                    tv3[p].setText(" " + th.lottery3[p]);
                }
                for (int p = 0; p < tv4.length; p++) {
                    tv4[p].setText(" " + th.lottery4[p]);
                }
                t++;
            }
        });

        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bundle =new Bundle();

                bundle.putInt("t",t);

                if(t>0) {
                    bundle.putIntArray(t + "a", thread.lottery);
                    bundle.putIntArray(t + "b", thread.lottery2);
                    bundle.putIntArray(t + "c", thread.lottery3);
                    bundle.putIntArray(t + "d", thread.lottery4);
                    intent.putExtras(bundle);
                }
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent);
            }
        });
    }
    private void initView() {
        for (int s = 0; s < tv.length; s++) {
            tv[s] = findViewById(a[s]);

            tv[s].setTextSize(15);
        }
        for (int s = 0; s < tv2.length; s++) {
            tv2[s] = findViewById(b[s]);

            tv2[s].setTextSize(15);
        }
        for (int s = 0; s < tv3.length; s++) {
            tv3[s] = findViewById(c[s]);

            tv3[s].setTextSize(15);
        }
        for (int s = 0; s < tv4.length; s++) {
            tv4[s] = findViewById(d[s]);

            tv4[s].setTextSize(15);
        }

    }
}

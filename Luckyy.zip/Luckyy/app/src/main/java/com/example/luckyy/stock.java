package com.example.luckyy;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


public class stock extends Activity {
    ListView tv;
    Bundle bundle;
    List<String> list;
    int t;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.stock);
        tv=findViewById(R.id.tv);

        bundle = getIntent().getExtras();

        if(bundle != null){
            list=getData().peek();
            tv.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, list));
            if(tv.getParent() != null) {
                ((ViewGroup)tv.getParent()).removeView(tv);
            }

            setContentView(tv);

        }
        else{

        }

//        FirebaseDatabase database = FirebaseDatabase.getInstance();
//        DatabaseReference myRef = database.getReference("message");
//        myRef.setValue(getData());


    }
    private Queue<List<String>> getData(){
        List<String> data = new ArrayList<String>();
        Queue<List<String>> q=new LinkedList<>();
        t =bundle.getInt("t");

        for(int g=1;g<=t;g++) {

            int[] a = bundle.getIntArray(g + "a");
            int[] aa = bundle.getIntArray(g+"b");
            int[] aaa = bundle.getIntArray(g+"c");
            int[] aaaa = bundle.getIntArray(g+"d");

            if(a != null) {
                data.add(Arrays.toString(a) + "\n" + Arrays.toString(aa) + "\n" + Arrays.toString(aaa) + "\n" + Arrays.toString(aaaa));
            }else {
                continue;
            }
                q.offer(data);
        }
        return q;
    }
}
